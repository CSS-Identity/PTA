$AgentConfigFile = "C:\Program Files\Microsoft Azure AD Connect Authentication Agent\AzureADConnectAuthenticationAgentService.exe.config"
$AgentDefaultLogFolder = "Azure AD Connect Authentication Agent"
$AgentServiceName = "Microsoft Azure AD Connect Authentication Agent"
$AgentLogFileName = "AzureADConnectAuthenticationAgent.log"